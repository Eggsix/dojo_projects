<?php
  foreach($posts as $post)
  {  ?>
    <li>
        <p><?= $post['description'] ?></p>
    </li>
<?php
  }  ?>